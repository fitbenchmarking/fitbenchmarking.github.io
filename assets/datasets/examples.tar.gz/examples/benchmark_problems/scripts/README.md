This folder contains scripts that have been used at various times to create more generic type data formatted files from more software specific type ones,
thereby allowing problem definition files referencing such data to be made easier available for benchmarking across minimizer libraries.
Of course, this is not aways feasible, but where it is it is recommended.
A particular simple format is column ascii format, for 2D data this is X and Y columns with an optional E column,
where the E column contains the errors of the Y values.